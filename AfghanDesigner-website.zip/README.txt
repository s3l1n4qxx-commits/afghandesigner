AFGHANDESIGNER STARTER WEBSITE

Preview:
- Open index.html in a browser.

What works:
- Responsive storefront layout
- Product categories and filtering
- Demo shopping basket and subtotal
- Demo newsletter form

Before taking real orders:
- Replace example products/prices with your real inventory and add genuine product photos.
- Update the contact email, shipping/returns, privacy and terms.
- Connect a reputable payment provider and server-side order handling. The current basket is demo-only and does not take payments.
- Do not collect or store card details yourself.

Free publishing (static demo):
1. Create an account on GitHub.
2. Create a new public repository named afghandesigner (or another name).
3. Upload index.html to the repository root.
4. In repository Settings -> Pages, choose deploy from branch, select main and /(root), then Save.
5. Wait for GitHub Pages to publish. Your free URL will look like https://YOUR-USERNAME.github.io/afghandesigner/

Alternative: Netlify Drop can publish a folder by dragging it into Netlify's manual deploy area. Check the current provider terms and settings.

A free static URL is suitable for showing the design, but a real shop needs secure checkout and order management. Since the user may be under 18, have a parent/guardian help with hosting/payment accounts and business/legal setup where required.
